<?php 

$_['heading_title'] = 'Facturalusa - Software de Facturação Online';
$_['text_extension'] = 'Extensions';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Facturalusa!';